#! /bin/bash
python3 8016392965_1357016181_4732217257_basic.py input.txt
